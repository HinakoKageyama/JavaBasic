package practice01;
/*
 * PTra01_04.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra01_04 {
	public static void main(String[] args) {
		
		float PI = 3.14F;
        System.out.println(PI);

		// ★ float型の変数 f を宣言してください


		// ★ 変数 f に 3.14 を代入してください


		// ★ 変数 f を出力してください

		


	}
}
