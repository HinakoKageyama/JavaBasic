package practice02;
/*
 * PTra02_01.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra02_01 {
	public static void main(String[] args) {

		// ★ 20を5で割った値を出力してください
		int x = 20;
		int y = 5;
		 System.out.println(x / y);
		    


		// ★ 126に13を掛けた値を出力してください
		 System.out.println(126 / 13);

		// ★ 97を6で割ったときの余りを出力してください
		 System.out.println(97 % 6);

	}
}
