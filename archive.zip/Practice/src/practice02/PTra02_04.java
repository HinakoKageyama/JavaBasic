package practice02;
/*
 * PTra02_04.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra02_04 {
	public static void main(String[] args) {
		int d_num = 25;

		// ★ d_num と d_num の合計をd_numに代入してください

		// ★ d_numの値を出力してください。


	}
}
