package practice02;
/*
 * PTra02_05.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra02_05 {
	public static void main(String[] args) {
		int age = 58;
		String name = "山田";

		// ★ 変数age, nameを連結して「山田さんは、58歳です」と出力してください
	}
}
