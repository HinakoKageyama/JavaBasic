package practice03;
/*
 * PTra03_01.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra03_01 {
	public static void main(String[] args) {
		// ★ int型の変数numを宣言し、70で初期化してください


		// ★ 「変数numが70である」という条件式を追加してください
		if() {
			System.out.println("条件に合致しました");
		}
	}
}
