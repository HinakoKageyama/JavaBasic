package practice03;
/*
 * PTra03_02.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra03_02 {
	public static void main(String[] args) {
		// ★ int型の変数numを宣言し、65で初期化してください


		// ★ 変数numの値が65以上の場合は「合格です」と出力し、それ以外であれば「不合格です」を出力してください
		// ※プログラムは何行書いても良いです


	}
}
